import React, { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import TopBar from '../../components/TopBar';
import RoundHeader from '../../components/RoundHeader';
import Mascot from '../../components/Mascot';
import WorldCompleteOverlay from '../../components/WorldCompleteOverlay';
import HandCursorLayer from '../../components/HandCursorLayer';
import { useWorldFlow } from '../../hooks/useWorldFlow';
import { useCursor } from '../../hooks/useCursor';
import { WORLDS } from '../../data/worlds';

const COLOR = WORLDS.visionValley.color;

export default function VisionValley() {
  const flow = useWorldFlow({ worldKey: 'visionValley', skill: 'vision', xpPerRound: 150, worldBonus: 200 });
  const containerRef = useRef(null);
  const cursor = useCursor(containerRef, !flow.completed);

  const roundConfigs = [
    { title: 'ROUND 1 — TRACK & TOUCH', comp: TrackTouch },
    { title: 'ROUND 2 — CATCH THE LIGHTS', comp: CatchLights },
    { title: 'ROUND 3 — SWIPE MATCH', comp: SwipeMatch },
    { title: 'ROUND 4 — PATTERN TRACE', comp: PatternTrace },
    { title: 'ROUND 5 — FOCUS CHALLENGE', comp: FocusChallenge },
  ];
  const current = roundConfigs[flow.roundIndex];
  const RoundComp = current.comp;

  return (
    <div>
      <TopBar worldColor={COLOR} roundCount={flow.totalRounds} currentRound={flow.roundNumber} />
      <div className="game-shell">
        {!flow.completed && (
          <>
            <RoundHeader title={current.title} subtitle={RoundComp.subtitle} color={COLOR} />
            <div className="play-area" ref={containerRef} style={{ '--world-color': COLOR }}>
              <HandCursorLayer
                videoRef={cursor.videoRef}
                pixel={cursor.pixel}
                cameraStatus={cursor.cameraStatus}
                handDetected={cursor.handDetected}
                pinching={cursor.pinching}
                interacting={cursor.pinching}
                color={COLOR}
                showMirror={true}
                showCursor={true}
              />
              <RoundComp
                key={flow.roundIndex}
                cursor={cursor}
                containerRef={containerRef}
                onSolved={(acc, msg) => flow.completeRound(acc, msg)}
                onWrong={flow.registerAttempt}
              />
            </div>
          </>
        )}
        {flow.completed && (
          <WorldCompleteOverlay
            title="👁️ VISION VALLEY MASTER!"
            subtitle="You completed all 5 rounds of Visual & Focus Quests!"
            color={COLOR}
            onRestart={flow.restart}
          />
        )}
      </div>
      <Mascot color={COLOR} icon="🦉" message={flow.message} />
    </div>
  );
}

/* ====================== Round 1: Track & Touch ======================
   The child follows a moving star with their hand. Dwell to capture. */
function TrackTouch({ cursor, onSolved }) {
  const [target, setTarget] = useState({ x: 50, y: 50 });
  const dwellRef = useRef(0);
  const lastTsRef = useRef(performance.now());
  const [progress, setProgress] = useState(0);
  const [showOnboard, setShowOnboard] = useState(true);
  const [goSignal, setGoSignal] = useState(false);
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    const t1 = setTimeout(() => { setShowOnboard(false); setGoSignal(true); }, 2200);
    const t2 = setTimeout(() => setGoSignal(false), 1000);
    const moveTarget = () => setTarget({ x: 15 + Math.random() * 70, y: 15 + Math.random() * 70 });
    moveTarget();
    const interval = setInterval(moveTarget, 2600);
    return () => { clearTimeout(t1); clearTimeout(t2); clearInterval(interval); };
  }, []);

  useEffect(() => {
    if (showOnboard) return;
    const now = performance.now();
    const dt = now - lastTsRef.current;
    lastTsRef.current = now;
    if (!cursor.pixel) return;
    const el = cursor.pixel;
    const dx = el.nx * 100 - target.x;
    const dy = el.ny * 100 - target.y;
    const dist = Math.hypot(dx, dy);
    if (dist < 9) {
      dwellRef.current = Math.min(1400, dwellRef.current + dt);
    } else {
      dwellRef.current = Math.max(0, dwellRef.current - dt * 1.5);
    }
    setProgress(dwellRef.current / 1400);
    if (dwellRef.current >= 1400) {
      // Spawn capture particles
      const newParticles = [];
      for (let i = 0; i < 16; i++) {
        newParticles.push({
          id: Date.now() + i,
          x: target.x,
          y: target.y,
          px: (Math.random() - 0.5) * 80,
          py: (Math.random() - 0.5) * 80,
        });
      }
      setParticles(newParticles);
      setTimeout(() => onSolved(1, 'Great tracking! You followed the starlight ✨'), 400);
    }
  }, [cursor.pixel, target, showOnboard, onSolved]);

  return (
    <>
      {!showOnboard && !goSignal && (
        <>
          <div
            className="floating-target"
            style={{
              left: `${target.x}%`,
              top: `${target.y}%`,
              '--slide': '0.3s',
              width: 48,
              height: 48,
              fontSize: 24,
            }}
          >
            ⭐
          </div>
          {/* Capture particles */}
          {particles.map((p) => (
            <div
              key={p.id}
              className="particle-burst"
              style={{
                left: `${p.x}%`,
                top: `${p.y}%`,
                background: COLOR,
                boxShadow: `0 0 8px ${COLOR}`,
                '--px': `${p.px}px`,
                '--py': `${p.py}px`,
              }}
            />
          ))}
          <div style={{ position: 'absolute', bottom: 18, left: '50%', transform: 'translateX(-50%)', width: 220 }}>
            <div className="progress-track" style={{ margin: 0 }}>
              <div className="progress-fill" style={{ width: `${Math.round(progress * 100)}%`, '--world-color': COLOR }} />
            </div>
          </div>
        </>
      )}
      {showOnboard && (
        <div className="onboard-instruction">
          <div className="onboard-icon">✋</div>
          <div className="onboard-text">Follow the star with your hand!</div>
          <div className="onboard-sub">Your magic cursor follows you</div>
        </div>
      )}
      {goSignal && (
        <div className="onboard-instruction" style={{ top: '40%' }}>
          <div className="go-badge">GO! 🚀</div>
        </div>
      )}
    </>
  );
}
TrackTouch.subtitle = 'Follow the floating starlight with your finger (or mouse)!';

/* ====================== Round 2: Catch the Lights ======================
   Multiple colored orbs float around. Hand touch = capture. Different from slash — pure touch mechanic. */
function CatchLights({ cursor, onSolved, onWrong }) {
  const total = 5;
  const [captured, setCaptured] = useState(0);
  const [orbs, setOrbs] = useState([]);
  const [showOnboard, setShowOnboard] = useState(true);
  const [goSignal, setGoSignal] = useState(false);
  const orbIdRef = useRef(0);
  const capturedRef = useRef(0);
  const [xpBursts, setXpBursts] = useState([]);

  const ORB_COLORS = ['#4fd8ff', '#ff5cad', '#ffc857', '#3ee08a', '#b98bff'];
  const ORB_ICONS = ['💎', '🌟', '🔮', '✨', '💜'];

  useEffect(() => {
    const t1 = setTimeout(() => { setShowOnboard(false); setGoSignal(true); }, 2200);
    const t2 = setTimeout(() => setGoSignal(false), 1000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  // Spawn orbs
  useEffect(() => {
    if (showOnboard) return undefined;
    let cancelled = false;
    function spawn() {
      if (cancelled) return;
      const idx = Math.floor(Math.random() * ORB_COLORS.length);
      const id = ++orbIdRef.current;
      setOrbs((prev) => [
        ...prev,
        {
          id,
          x: 15 + Math.random() * 70,
          y: 15 + Math.random() * 70,
          color: ORB_COLORS[idx],
          icon: ORB_ICONS[idx],
          size: 40 + Math.random() * 20,
          born: Date.now(),
          drift: { x: (Math.random() - 0.5) * 0.4, y: (Math.random() - 0.5) * 0.4 },
        },
      ]);
    }
    spawn();
    const interval = setInterval(spawn, 1800);
    return () => { cancelled = true; clearInterval(interval); };
  }, [showOnboard]);

  // Drift orbs
  useEffect(() => {
    let raf;
    function tick() {
      setOrbs((prev) =>
        prev.map((o) => ({
          ...o,
          x: Math.max(5, Math.min(90, o.x + o.drift.x)),
          y: Math.max(5, Math.min(90, o.y + o.drift.y)),
        }))
      );
      raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  // Collision check
  useEffect(() => {
    if (!cursor.pixel || showOnboard || goSignal) return;
    const cx = cursor.pixel.nx * 100;
    const cy = cursor.pixel.ny * 100;

    setOrbs((prev) => {
      let hit = false;
      const remaining = [];
      for (const orb of prev) {
        const dist = Math.hypot(cx - orb.x, cy - orb.y);
        if (dist < 8) {
          hit = true;
          capturedRef.current++;
          setCaptured(capturedRef.current);
          setXpBursts((p) => [...p, { id: Date.now(), x: orb.x, y: orb.y, xp: 15 }]);
          if (capturedRef.current >= total) {
            setTimeout(() => onSolved(1, 'All lights caught! Amazing vision! 🌟'), 300);
          }
        } else {
          remaining.push(orb);
        }
      }
      return hit ? remaining : prev;
    });
  }, [cursor.pixel, showOnboard, goSignal, total, onSolved]);

  useEffect(() => {
    if (xpBursts.length === 0) return;
    const t = setTimeout(() => setXpBursts((p) => p.slice(1)), 1000);
    return () => clearTimeout(t);
  }, [xpBursts]);

  return (
    <>
      <div className="game-score-panel">
        <div className="game-score-item">
          ⚡ Caught: <span className="score-value">{captured}/{total}</span>
        </div>
      </div>

      {orbs.map((orb) => (
        <div
          key={orb.id}
          className="floating-target"
          style={{
            left: `${orb.x}%`,
            top: `${orb.y}%`,
            width: orb.size,
            height: orb.size,
            fontSize: orb.size * 0.5,
            background: `radial-gradient(circle, ${orb.color}33, transparent)`,
            borderColor: orb.color,
            boxShadow: `0 0 20px ${orb.color}`,
            '--slide': '0.2s',
          }}
        >
          {orb.icon}
        </div>
      ))}

      {xpBursts.map((b) => (
        <div key={b.id} className="xp-burst" style={{ left: `${b.x}%`, top: `${b.y - 5}%` }}>
          +{b.xp} XP ✨
        </div>
      ))}

      {showOnboard && (
        <div className="onboard-instruction">
          <div className="onboard-icon">🎯</div>
          <div className="onboard-text">Touch the glowing orbs!</div>
          <div className="onboard-sub">Move your hand to catch them</div>
        </div>
      )}
      {goSignal && (
        <div className="onboard-instruction" style={{ top: '40%' }}>
          <div className="go-badge">GO! 🚀</div>
        </div>
      )}
    </>
  );
}
CatchLights.subtitle = 'Touch the floating light orbs before they drift away!';

/* ====================== Round 3: Swipe Match ======================
   Swipe-based matching — move hand left for option A, right for option B. */
function SwipeMatch({ cursor, onSolved, onWrong }) {
  const COLORS_A = [
    { name: 'Cyan Crystal', color: '#4fd8ff', emoji: '💎' },
    { name: 'Magenta Flame', color: '#ff5cad', emoji: '🔥' },
  ];
  const target = useMemo(() => COLORS_A[Math.floor(Math.random() * COLORS_A.length)], []);
  const [answered, setAnswered] = useState(false);
  const [showOnboard, setShowOnboard] = useState(true);
  const [goSignal, setGoSignal] = useState(false);
  const [swipeHint, setSwipeHint] = useState(null);

  useEffect(() => {
    const t1 = setTimeout(() => { setShowOnboard(false); setGoSignal(true); }, 2200);
    const t2 = setTimeout(() => setGoSignal(false), 1000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  // Track hand position for swipe detection
  useEffect(() => {
    if (showOnboard || goSignal || answered || !cursor.pixel) return;
    const nx = cursor.pixel.nx;
    if (nx < 0.35) {
      // Swipe left — Cyan
      setSwipeHint('left');
      setTimeout(() => {
        setAnswered(true);
        if (target.color === '#4fd8ff') onSolved(1, 'Perfect match! 💎');
        else { onWrong(); onSolved(0.5, 'Not quite — try the other direction!'); }
      }, 300);
    } else if (nx > 0.65) {
      // Swipe right — Magenta
      setSwipeHint('right');
      setTimeout(() => {
        setAnswered(true);
        if (target.color === '#ff5cad') onSolved(1, 'Perfect match! 🔥');
        else { onWrong(); onSolved(0.5, 'Not quite — try the other direction!'); }
      }, 300);
    }
  }, [cursor.pixel, showOnboard, goSignal, answered, target, onSolved, onWrong]);

  return (
    <>
      {!showOnboard && !goSignal && (
        <>
          {/* Two sides */}
          <div style={{ position: 'absolute', left: 20, top: '50%', transform: 'translateY(-50%)', textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 8 }}>💎</div>
            <div style={{ fontSize: 13, color: '#4fd8ff', fontWeight: 700 }}>← Cyan</div>
          </div>
          <div style={{ position: 'absolute', left: '50%', top: 16, transform: 'translateX(-50%)', textAlign: 'center' }}>
            <div style={{ fontSize: 18, fontWeight: 800, color: 'var(--text-hi)' }}>Target:</div>
            <div style={{ fontSize: 36, marginTop: 4 }}>{target.emoji}</div>
            <div style={{ fontSize: 14, color: target.color, fontWeight: 700, marginTop: 4 }}>{target.name}</div>
          </div>
          <div style={{ position: 'absolute', right: 20, top: '50%', transform: 'translateY(-50%)', textAlign: 'center' }}>
            <div style={{ fontSize: 48, marginBottom: 8 }}>🔥</div>
            <div style={{ fontSize: 13, color: '#ff5cad', fontWeight: 700 }}>Magenta →</div>
          </div>

          {/* Swipe hint */}
          {swipeHint && (
            <div style={{
              position: 'absolute', bottom: 30, left: '50%', transform: 'translateX(-50%)',
              fontSize: 14, color: 'var(--text-mid)', fontWeight: 700,
              animation: 'fade-in 0.2s ease',
            }}>
              {swipeHint === 'left' ? '← Swiping left!' : 'Swiping right! →'}
            </div>
          )}

          {/* Click fallback buttons */}
          <div style={{ position: 'absolute', bottom: 60, left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 20 }}>
            <button
              className="btn-pill"
              style={{ background: 'rgba(79,216,255,0.2)', border: '2px solid #4fd8ff', color: '#4fd8ff' }}
              onClick={() => { setAnswered(true); if (target.color === '#4fd8ff') onSolved(1, 'Perfect match! 💎'); else { onWrong(); onSolved(0.5, 'Not quite!'); } }}
            >
              💎 Cyan
            </button>
            <button
              className="btn-pill"
              style={{ background: 'rgba(255,92,173,0.2)', border: '2px solid #ff5cad', color: '#ff5cad' }}
              onClick={() => { setAnswered(true); if (target.color === '#ff5cad') onSolved(1, 'Perfect match! 🔥'); else { onWrong(); onSolved(0.5, 'Not quite!'); } }}
            >
              🔥 Magenta
            </button>
          </div>
        </>
      )}
      {showOnboard && (
        <div className="onboard-instruction">
          <div className="onboard-icon">👋</div>
          <div className="onboard-text">Swipe to match!</div>
          <div className="onboard-sub">Move hand left or right to choose</div>
        </div>
      )}
      {goSignal && (
        <div className="onboard-instruction" style={{ top: '40%' }}>
          <div className="go-badge">GO! 🚀</div>
        </div>
      )}
    </>
  );
}
SwipeMatch.subtitle = 'Move your hand LEFT or RIGHT to match the target crystal!';

/* ====================== Round 4: Pattern Trace ======================
   Trace a path between points in order using the cursor. */
function PatternTrace({ cursor, containerRef, onSolved }) {
  const points = useMemo(() => {
    const pts = [];
    const n = 4;
    for (let i = 0; i < n; i++) {
      pts.push({
        x: 15 + (i % 2 === 0 ? 20 : 60) + Math.random() * 10,
        y: 15 + Math.floor(i / 2) * 35 + Math.random() * 10,
        visited: false,
      });
    }
    return pts;
  }, []);

  const [visited, setVisited] = useState(() => new Array(points.length).fill(false));
  const [showOnboard, setShowOnboard] = useState(true);
  const [goSignal, setGoSignal] = useState(false);
  const visitedRef = useRef(new Array(points.length).fill(false));
  const [trail, setTrail] = useState([]);
  const trailRef = useRef([]);

  useEffect(() => {
    const t1 = setTimeout(() => { setShowOnboard(false); setGoSignal(true); }, 2200);
    const t2 = setTimeout(() => setGoSignal(false), 1000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  // Track cursor trail and check proximity to next unvisited point
  useEffect(() => {
    if (!cursor.pixel || showOnboard || goSignal) return;
    const cx = cursor.pixel.nx * 100;
    const cy = cursor.pixel.ny * 100;

    // Add to trail
    trailRef.current.push({ x: cx, y: cy });
    if (trailRef.current.length > 60) trailRef.current = trailRef.current.slice(-60);
    setTrail([...trailRef.current]);

    // Find next unvisited point
    const nextIdx = visitedRef.current.findIndex((v) => !v);
    if (nextIdx < 0) return;

    const pt = points[nextIdx];
    const dist = Math.hypot(cx - pt.x, cy - pt.y);
    if (dist < 8) {
      visitedRef.current[nextIdx] = true;
      setVisited([...visitedRef.current]);

      // Check if all visited
      if (visitedRef.current.every(Boolean)) {
        setTimeout(() => onSolved(1, 'Pattern traced perfectly! 🔮'), 400);
      }
    }
  }, [cursor.pixel, showOnboard, goSignal, points, onSolved]);

  const pathD = trail.length > 1
    ? trail.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ')
    : '';

  return (
    <>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none', zIndex: 5 }}>
        {trail.length > 1 && (
          <path d={pathD} fill="none" stroke={COLOR} strokeWidth="0.8" strokeLinecap="round" filter="url(#glow)" opacity="0.6" />
        )}
        {points.map((pt, i) => (
          <g key={i}>
            <circle
              cx={pt.x} cy={pt.y} r={visited[i] ? 2 : 3}
              fill={visited[i] ? COLOR : 'none'}
              stroke={visited[i] ? COLOR : 'rgba(255,255,255,0.3)'}
              strokeWidth="0.5"
              opacity={visited[i] ? 1 : 0.6}
            />
            <text x={pt.x} y={pt.y + 0.5} textAnchor="middle" dominantBaseline="middle" fontSize="4" fill="white" fontWeight="bold">
              {i + 1}
            </text>
          </g>
        ))}
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="1" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
      </svg>

      {!showOnboard && !goSignal && (
        <div className="game-score-panel">
          <div className="game-score-item">
            ⚡ Points: <span className="score-value">{visited.filter(Boolean).length}/{points.length}</span>
          </div>
          <div style={{ fontSize: 11, color: 'var(--text-low)', padding: '4px 14px' }}>
            Trace from 1 → 2 → 3 → 4
          </div>
        </div>
      )}

      {showOnboard && (
        <div className="onboard-instruction">
          <div className="onboard-icon">🔮</div>
          <div className="onboard-text">Trace the glowing points!</div>
          <div className="onboard-sub">Move your hand from 1 to 4</div>
        </div>
      )}
      {goSignal && (
        <div className="onboard-instruction" style={{ top: '40%' }}>
          <div className="go-badge">GO! 🚀</div>
        </div>
      )}
    </>
  );
}
PatternTrace.subtitle = 'Trace through the glowing points in order!';

/* ====================== Round 5: Focus Challenge ======================
   Stars appear and fade. Hand touch = capture before they disappear. Faster pace. */
function FocusChallenge({ cursor, onSolved, onWrong }) {
  const total = 4;
  const [found, setFound] = useState(0);
  const [star, setStar] = useState({ x: 50, y: 50 });
  const [expiring, setExpiring] = useState(false);
  const [showOnboard, setShowOnboard] = useState(true);
  const [goSignal, setGoSignal] = useState(false);
  const foundRef = useRef(0);
  const [xpBursts, setXpBursts] = useState([]);

  useEffect(() => {
    const t1 = setTimeout(() => { setShowOnboard(false); setGoSignal(true); }, 2200);
    const t2 = setTimeout(() => setGoSignal(false), 1000);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  useEffect(() => {
    if (showOnboard || goSignal) return;
    const t = setTimeout(() => setExpiring(true), 2000);
    return () => clearTimeout(t);
  }, [star, showOnboard, goSignal]);

  useEffect(() => {
    if (!expiring) return undefined;
    const t = setTimeout(() => {
      onWrong();
      setStar({ x: 15 + Math.random() * 70, y: 15 + Math.random() * 70 });
      setExpiring(false);
    }, 800);
    return () => clearTimeout(t);
  }, [expiring, onWrong]);

  // Collision
  useEffect(() => {
    if (!cursor.pixel || showOnboard || goSignal || expiring) return;
    const cx = cursor.pixel.nx * 100;
    const cy = cursor.pixel.ny * 100;
    const dist = Math.hypot(cx - star.x, cy - star.y);
    if (dist < 8) {
      foundRef.current++;
      setFound(foundRef.current);
      setExpiring(false);
      setXpBursts((p) => [...p, { id: Date.now(), x: star.x, y: star.y, xp: 20 }]);
      if (foundRef.current >= total) {
        setTimeout(() => onSolved(1, 'Amazing focus! All stars caught 🌟'), 300);
      } else {
        setStar({ x: 15 + Math.random() * 70, y: 15 + Math.random() * 70 });
      }
    }
  }, [cursor.pixel, star, showOnboard, goSignal, expiring, total, onSolved]);

  useEffect(() => {
    if (xpBursts.length === 0) return;
    const t = setTimeout(() => setXpBursts((p) => p.slice(1)), 1000);
    return () => clearTimeout(t);
  }, [xpBursts]);

  return (
    <>
      <div className="game-score-panel">
        <div className="game-score-item">
          ⚡ Stars: <span className="score-value">{found}/{total}</span>
        </div>
      </div>

      {!showOnboard && !goSignal && (
        <div
          className="floating-target"
          style={{
            left: `${star.x}%`,
            top: `${star.y}%`,
            opacity: expiring ? 0.3 : 1,
            '--slide': '0.3s',
            width: 52,
            height: 52,
            fontSize: 26,
            transition: 'opacity 0.3s',
          }}
        >
          ⭐
        </div>
      )}

      {xpBursts.map((b) => (
        <div key={b.id} className="xp-burst" style={{ left: `${b.x}%`, top: `${b.y - 5}%` }}>
          +{b.xp} XP ✨
        </div>
      ))}

      {showOnboard && (
        <div className="onboard-instruction">
          <div className="onboard-icon">⚡</div>
          <div className="onboard-text">Touch the stars before they fade!</div>
          <div className="onboard-sub">Move fast — they won't wait!</div>
        </div>
      )}
      {goSignal && (
        <div className="onboard-instruction" style={{ top: '40%' }}>
          <div className="go-badge">GO! 🚀</div>
        </div>
      )}
    </>
  );
}
FocusChallenge.subtitle = 'Touch the glowing stars before they drift away!';
