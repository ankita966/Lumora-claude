import React, { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import TopBar from '../../components/TopBar';
import RoundHeader from '../../components/RoundHeader';
import Mascot from '../../components/Mascot';
import WorldCompleteOverlay from '../../components/WorldCompleteOverlay';
import HandCursorLayer from '../../components/HandCursorLayer';
import { useWorldFlow } from '../../hooks/useWorldFlow';
import { useCursor } from '../../hooks/useCursor';
import { useSpeechRecognition, speak, wordOverlapScore, isSpeechRecognitionSupported } from '../../hooks/useSpeechRecognition';
import { WORLDS } from '../../data/worlds';

const COLOR = WORLDS.soundForest.color;

// word: label, emoji, starting phoneme
const WORD_BANK = [
  { word: 'Rabbit', emoji: '🐰', sound: '/r/' },
  { word: 'Rocket', emoji: '🚀', sound: '/r/' },
  { word: 'Rainbow', emoji: '🌈', sound: '/r/' },
  { word: 'Robot', emoji: '🤖', sound: '/r/' },
  { word: 'Lion', emoji: '🦁', sound: '/l/' },
  { word: 'Frog', emoji: '🐸', sound: '/f/' },
  { word: 'Cupcake', emoji: '🧁', sound: '/k/' },
  { word: 'Sun', emoji: '☀️', sound: '/s/' },
  { word: 'Star', emoji: '⭐', sound: '/s/' },
  { word: 'Moon', emoji: '🌙', sound: '/m/' },
  { word: 'Bat', emoji: '🦇', sound: '/b/' },
  { word: 'Duck', emoji: '🦆', sound: '/d/' },
  { word: 'Cat', emoji: '🐱', sound: '/k/' },
  { word: 'Fish', emoji: '🐟', sound: '/f/' },
  { word: 'Apple', emoji: '🍎', sound: '/a/' },
  { word: 'Banana', emoji: '🍌', sound: '/b/' },
  { word: 'Dog', emoji: '🐶', sound: '/d/' },
  { word: 'Elephant', emoji: '🐘', sound: '/e/' },
];

function shuffled(arr) {
  return [...arr].sort(() => Math.random() - 0.5);
}

export default function SoundForest() {
  const flow = useWorldFlow({ worldKey: 'soundForest', skill: 'sound', xpPerRound: 150, worldBonus: 200 });

  const roundConfigs = [
    { title: 'ROUND 1 — SLASH QUEST', comp: SoundSlash },
    { title: 'ROUND 2 — SOUND MATCH', comp: SoundMatch },
    { title: 'ROUND 3 — PHONEME BLEND', comp: PhonemeBlend },
    { title: 'ROUND 4 — PRONOUNCE IT', comp: PronounceIt },
    { title: 'ROUND 5 — WORD RECOGNITION', comp: WordRecognitionRound },
  ];
  const current = roundConfigs[flow.roundIndex];
  const RoundComp = current.comp;

  return (
    <div>
      <TopBar worldColor={COLOR} roundCount={flow.totalRounds} currentRound={flow.roundNumber} />
      <div className="game-shell">
        {!flow.completed && (
          <>
            <RoundHeader title={current.title} subtitle={RoundComp.subtitle} color={COLOR} />
            <div className="play-area" style={{ '--world-color': COLOR }}>
              <RoundComp key={flow.roundIndex} onSolved={(acc, msg) => flow.completeRound(acc, msg)} onWrong={flow.registerAttempt} />
            </div>
          </>
        )}
        {flow.completed && (
          <WorldCompleteOverlay
            title="🌲 SOUND FOREST MASTER!"
            subtitle="You completed all 5 rounds of Sound & Phoneme Quests!"
            color={COLOR}
            onRestart={flow.restart}
          />
        )}
      </div>
      <Mascot color={COLOR} icon="🐯" message={flow.message} />
    </div>
  );
}

/* ====================== Round 1: Sound Slash ======================
   Real Fruit-Ninja-style hand-controlled slash mechanic.
   Objects float through the game world. The child uses their REAL HAND.
   The cyan magic cursor follows their fingertip.
   When the cursor trajectory intersects an object → object slices/splits. */
function SoundSlash({ onSolved, onWrong }) {
  const containerRef = useRef(null);
  const cursor = useCursor(containerRef, true);

  const target = useMemo(() => WORD_BANK[Math.floor(Math.random() * WORD_BANK.length)], []);
  const matching = useMemo(() => WORD_BANK.filter((w) => w.sound === target.sound), [target]);
  const others = useMemo(() => WORD_BANK.filter((w) => w.sound !== target.sound), [target]);

  const goal = Math.min(4, matching.length);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [objects, setObjects] = useState([]);
  const [slices, setSlices] = useState([]); // slice particle effects
  const [xpBursts, setXpBursts] = useState([]);
  const [trailPoints, setTrailPoints] = useState([]);
  const [showOnboard, setShowOnboard] = useState(true);
  const [goSignal, setGoSignal] = useState(false);
  const trailRef = useRef([]);
  const scoreRef = useRef(0);
  const comboRef = useRef(0);
  const objectIdRef = useRef(0);
  const lastSpawnRef = useRef(0);
  const containerSizeRef = useRef({ w: 880, h: 380 });

  useEffect(() => {
    speak(`Slash everything starting with the ${target.sound.replace(/\//g, '')} sound!`);
    // Show onboarding then GO!
    const t1 = setTimeout(() => {
      setShowOnboard(false);
      setGoSignal(true);
    }, 2800);
    const t2 = setTimeout(() => setGoSignal(false), 1200);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [target]);

  // Track container size
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const update = () => {
      const rect = el.getBoundingClientRect();
      containerSizeRef.current = { w: rect.width, h: rect.height };
    };
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, []);

  // Spawn objects
  useEffect(() => {
    if (showOnboard) return undefined;
    let cancelled = false;
    function spawn() {
      if (cancelled) return;
      const useMatch = Math.random() < 0.5;
      const bank = useMatch ? matching : others;
      const item = bank[Math.floor(Math.random() * bank.length)];
      const id = ++objectIdRef.current;
      const w = containerSizeRef.current.w;
      const h = containerSizeRef.current.h;
      setObjects((prev) => [
        ...prev,
        {
          ...item,
          id,
          x: 60 + Math.random() * (w - 120),
          y: h + 20,
          speed: 0.6 + Math.random() * 0.5,
          rotation: Math.random() * 360,
          wobble: Math.random() * Math.PI * 2,
          born: Date.now(),
        },
      ]);
    }
    spawn();
    spawn();
    const interval = setInterval(spawn, 1400);
    return () => { cancelled = true; clearInterval(interval); };
  }, [showOnboard, matching, others]);

  // Animate objects upward
  useEffect(() => {
    let raf;
    function tick() {
      setObjects((prev) =>
        prev
          .map((o) => ({
            ...o,
            y: o.y - o.speed,
            x: o.x + Math.sin((Date.now() - o.born) * 0.002 + o.wobble) * 0.3,
            rotation: o.rotation + 0.5,
          }))
          .filter((o) => o.y > -80) // remove off-screen
      );
      raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  // Track cursor trail for collision
  useEffect(() => {
    if (!cursor.pixel || showOnboard) return;
    trailRef.current.push({
      x: cursor.pixel.x,
      y: cursor.pixel.y,
      t: Date.now(),
    });
    if (trailRef.current.length > 30) trailRef.current = trailRef.current.slice(-30);
    setTrailPoints([...trailRef.current]);
  }, [cursor.pixel, showOnboard]);

  // Collision detection — check trail against objects
  useEffect(() => {
    if (trailRef.current.length < 2 || objects.length === 0) return;
    const w = containerSizeRef.current.w;
    const h = containerSizeRef.current.h;
    const trail = trailRef.current;
    const last = trail[trail.length - 1];
    const prev = trail.length >= 2 ? trail[trail.length - 2] : last;

    const cursorX = last.x;
    const cursorY = last.y;
    const prevX = prev.x;
    const prevY = prev.y;

    setObjects((prevObjects) => {
      let hit = false;
      const remaining = [];
      for (const obj of prevObjects) {
        const objR = 32; // radius in pixels
        // Check if cursor is near the object
        const dx = cursorX - obj.x;
        const dy = cursorY - obj.y;
        const dist = Math.hypot(dx, dy);

        if (dist < objR + 14) {
          // HIT!
          hit = true;
          const isCorrect = obj.sound === target.sound;

          // Spawn slice particles
          const particles = [];
          for (let i = 0; i < 12; i++) {
            const angle = (i / 12) * Math.PI * 2;
            particles.push({
              id: Date.now() + i,
              x: obj.x,
              y: obj.y,
              px: Math.cos(angle) * (40 + Math.random() * 40),
              py: Math.sin(angle) * (40 + Math.random() * 40),
              char: i < 6 ? obj.emoji : '✨',
              life: 1,
            });
          }

          if (isCorrect) {
            setScore((s) => s + 1);
            scoreRef.current++;
            setCombo((c) => c + 1);
            comboRef.current++;

            // XP burst
            const xp = 10 + comboRef.current * 5;
            setXpBursts((prev) => [
              ...prev,
              { id: Date.now(), x: obj.x, y: obj.y, xp },
            ]);

            if (scoreRef.current >= goal) {
              setTimeout(() => {
                onSolved(1, `Amazing slash! All ${target.sound} sounds found! 🍃`);
              }, 300);
            }
          } else {
            setCombo(0);
            comboRef.current = 0;
            onWrong();
          }

          setSlices((prev) => [...prev, ...particles]);
          // Remove particle effects after animation
          setTimeout(() => {
            setSlices((prev) => prev.filter((p) => !particles.includes(p)));
          }, 600);
        } else {
          remaining.push(obj);
        }
      }
      return hit ? remaining : prevObjects;
    });
  }, [trailPoints, objects, target, goal, onSolved, onWrong]);

  // Clean up XP bursts
  useEffect(() => {
    if (xpBursts.length === 0) return;
    const t = setTimeout(() => setXpBursts((prev) => prev.slice(1)), 1000);
    return () => clearTimeout(t);
  }, [xpBursts]);

  return (
    <div ref={containerRef} style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden' }}>
      {/* HandCursorLayer with MagicMirror + MagicCursor */}
      <HandCursorLayer
        videoRef={cursor.videoRef}
        pixel={cursor.pixel}
        cameraStatus={cursor.cameraStatus}
        handDetected={cursor.handDetected}
        pinching={cursor.pinching}
        interacting={cursor.pinching}
        color={COLOR}
        showMirror={true}
        showCursor={true}
      />

      {/* Score panel */}
      <div className="game-score-panel">
        <div className="game-score-item">
          🎯 Target: {target.emoji} {target.word} ({target.sound})
        </div>
        <div className="game-score-item">
          ⚡ Score: <span className="score-value">{score}/{goal}</span>
        </div>
        {comboRef.current > 1 && (
          <div className="game-score-item" style={{ color: 'var(--gold)' }}>
            🔥 Combo x{comboRef.current}
          </div>
        )}
      </div>

      {/* Floating objects */}
      {objects.map((obj) => (
        <div
          key={obj.id}
          className="slash-object"
          style={{
            left: obj.x - 32,
            top: obj.y - 32,
            transform: `rotate(${obj.rotation}deg)`,
            '--world-color': obj.sound === target.sound ? COLOR : 'rgba(255,255,255,0.3)',
            borderColor: obj.sound === target.sound ? COLOR : 'rgba(255,255,255,0.15)',
            fontSize: 28,
          }}
        >
          {obj.emoji}
        </div>
      ))}

      {/* Slice particle effects */}
      {slices.map((p) => (
        <div
          key={p.id}
          className="slice-part"
          style={{
            left: p.x,
            top: p.y,
            '--px': `${p.px}px`,
            '--py': `${p.py}px`,
            '--pr': `${Math.random() * 90 - 45}deg`,
          }}
        >
          {p.char}
        </div>
      ))}

      {/* XP bursts */}
      {xpBursts.map((b) => (
        <div
          key={b.id}
          className="xp-burst"
          style={{ left: b.x, top: b.y - 20 }}
        >
          +{b.xp} XP ✨
        </div>
      ))}

      {/* Onboarding instruction */}
      {showOnboard && (
        <div className="onboard-instruction">
          <div className="onboard-icon">✋</div>
          <div className="onboard-text">Move your hand to slash!</div>
          <div className="onboard-sub">Your magic cursor follows you</div>
        </div>
      )}

      {/* GO signal */}
      {goSignal && (
        <div className="onboard-instruction" style={{ top: '40%' }}>
          <div className="go-badge">GO! 🚀</div>
        </div>
      )}
    </div>
  );
}
SoundSlash.subtitle = 'Slash everything that starts with the highlighted sound! ✋✨';

/* ---------------- Round 2: Sound Match ---------------- */
function SoundMatch({ onSolved, onWrong }) {
  const target = useMemo(() => WORD_BANK[Math.floor(Math.random() * WORD_BANK.length)], []);
  const choices = useMemo(() => {
    const correct = target;
    const wrong = shuffled(WORD_BANK.filter((w) => w.sound !== target.sound)).slice(0, 3);
    return shuffled([correct, ...wrong]);
  }, [target]);
  const [answered, setAnswered] = useState(false);

  useEffect(() => { speak(`${target.word}`); }, [target]);

  function choose(item) {
    if (answered) return;
    setAnswered(true);
    if (item.word === target.word) onSolved(1, `Yes! ${item.word} starts like ${target.word} 🌟`);
    else {
      onWrong();
      setTimeout(() => setAnswered(false), 500);
      onSolved(0.6, `Listen again — we want the ${target.sound} sound.`);
    }
  }

  return (
    <div style={{ textAlign: 'center' }}>
      <button
        className="panel-card"
        style={{ marginBottom: 30, display: 'inline-flex', gap: 10, alignItems: 'center', cursor: 'pointer', border: 'none' }}
        onClick={() => speak(target.word)}
      >
        <span style={{ fontSize: 22 }}>{target.emoji}</span>
        <span style={{ fontWeight: 800, color: 'var(--text-hi)' }}>{target.word.toUpperCase()} ({target.sound})</span>
        <span>🔊</span>
      </button>
      <div className="choice-row">
        {choices.map((c) => (
          <button key={c.word} className="choice-item" onClick={() => choose(c)}>
            <div className="choice-orb">{c.emoji}</div>
            <span className="choice-label">{c.word}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
SoundMatch.subtitle = 'Find the word that starts like the highlighted sound!';

/* ---------------- Round 3: Phoneme Blend ---------------- */
const BLEND_WORDS = [
  { word: 'Cat', parts: ['c', 'a', 't'], emoji: '🐱' },
  { word: 'Sun', parts: ['s', 'u', 'n'], emoji: '☀️' },
  { word: 'Bat', parts: ['b', 'a', 't'], emoji: '🦇' },
  { word: 'Dog', parts: ['d', 'o', 'g'], emoji: '🐶' },
];
function PhonemeBlend({ onSolved, onWrong }) {
  const target = useMemo(() => BLEND_WORDS[Math.floor(Math.random() * BLEND_WORDS.length)], []);
  const choices = useMemo(() => shuffled([target, ...shuffled(BLEND_WORDS.filter((w) => w.word !== target.word)).slice(0, 2)]), [target]);
  const [playedIdx, setPlayedIdx] = useState(-1);
  const [answered, setAnswered] = useState(false);

  useEffect(() => {
    let i = 0;
    const step = () => {
      setPlayedIdx(i);
      speak(target.parts[i], { rate: 0.8 });
      i += 1;
      if (i < target.parts.length) setTimeout(step, 750);
    };
    const t = setTimeout(step, 400);
    return () => clearTimeout(t);
  }, [target]);

  function choose(c) {
    if (answered) return;
    setAnswered(true);
    if (c.word === target.word) onSolved(1, `Blended it perfectly: ${target.word}! 🎶`);
    else {
      onWrong();
      setTimeout(() => setAnswered(false), 500);
      onSolved(0.5, 'Listen to each sound again, then blend them together.');
    }
  }

  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ display: 'flex', gap: 14, justifyContent: 'center', marginBottom: 26 }}>
        {target.parts.map((p, i) => (
          <div
            key={i}
            style={{
              width: 56, height: 56, borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 22, fontWeight: 800, background: 'rgba(255,255,255,0.05)',
              border: `2px solid ${playedIdx === i ? COLOR : 'rgba(255,255,255,0.15)'}`,
              boxShadow: playedIdx === i ? `0 0 16px ${COLOR}` : 'none',
              transition: 'all 0.3s',
            }}
          >
            {p}
          </div>
        ))}
      </div>
      <p style={{ color: 'var(--text-mid)', marginBottom: 20 }}>What word do these sounds make?</p>
      <div className="choice-row">
        {choices.map((c) => (
          <button key={c.word} className="choice-item" onClick={() => choose(c)}>
            <div className="choice-orb">{c.emoji}</div>
            <span className="choice-label">{c.word}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
PhonemeBlend.subtitle = 'Listen to each sound, then blend them into a word!';

/* ---------------- Round 4: Pronounce It (voice) ---------------- */
function PronounceIt({ onSolved, onWrong }) {
  const target = useMemo(() => WORD_BANK[Math.floor(Math.random() * WORD_BANK.length)], []);
  const speech = useSpeechRecognition({ lang: 'en-US' });
  const supported = isSpeechRecognitionSupported();
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    if (!speech.transcript || checked) return;
    setChecked(true);
    const score = wordOverlapScore(target.word, speech.transcript);
    if (score >= 0.5) onSolved(1, `Beautiful pronunciation of "${target.word}"! 🎤`);
    else {
      onWrong();
      setTimeout(() => setChecked(false), 500);
      onSolved(0.5, `I heard "${speech.transcript}" — let's try "${target.word}" again.`);
    }
  }, [speech.transcript, checked, target, onSolved, onWrong]);

  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: 54, marginBottom: 10 }}>{target.emoji}</div>
      <div style={{ fontWeight: 800, fontSize: 20, marginBottom: 22 }}>{target.word}</div>

      {supported ? (
        <>
          <button
            className={`mic-button ${speech.listening ? 'listening' : ''}`}
            onClick={() => (speech.listening ? speech.stop() : speech.start())}
          >
            🎤
          </button>
          <p style={{ color: 'var(--text-mid)', fontSize: 13, marginTop: 14 }}>
            {speech.listening
              ? 'Listening… say the word out loud!'
              : speech.permission === 'denied'
              ? 'Microphone permission denied — you can retry below.'
              : 'Tap the mic, then say the word.'}
          </p>
          {speech.interim && <p style={{ color: 'var(--text-low)', fontSize: 13 }}>Hearing: "{speech.interim}"</p>}
          {speech.error && <p style={{ color: '#ff9a9a', fontSize: 12 }}>{speech.error}</p>}
        </>
      ) : (
        <div>
          <p style={{ color: 'var(--text-mid)', fontSize: 13, marginBottom: 14 }}>
            Speech recognition isn't available in this browser. Say the word out loud, then confirm below.
          </p>
          <button className="btn-pill btn-primary" onClick={() => onSolved(1, `Great job practicing "${target.word}"! 🎤`)}>
            I said it! ✓
          </button>
        </div>
      )}
      <div style={{ marginTop: 16 }}>
        <button className="btn-pill btn-ghost" style={{ borderColor: COLOR }} onClick={() => speak(target.word)}>
          🔊 Hear it again
        </button>
      </div>
    </div>
  );
}
PronounceIt.subtitle = 'Say the word out loud into the microphone.';

/* ---------------- Round 5: Word Recognition ---------------- */
function WordRecognitionRound({ onSolved, onWrong }) {
  const target = useMemo(() => WORD_BANK[Math.floor(Math.random() * WORD_BANK.length)], []);
  const choices = useMemo(() => shuffled([target, ...shuffled(WORD_BANK.filter((w) => w.word !== target.word)).slice(0, 3)]), [target]);
  const [answered, setAnswered] = useState(false);

  function choose(c) {
    if (answered) return;
    setAnswered(true);
    if (c.word === target.word) onSolved(1, 'Word recognized perfectly! 📖');
    else {
      onWrong();
      setTimeout(() => setAnswered(false), 500);
      onSolved(0.6, `That word was ${target.word}.`);
    }
  }

  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: 60, marginBottom: 20 }}>{target.emoji}</div>
      <p style={{ color: 'var(--text-mid)', marginBottom: 18 }}>Which word matches the picture?</p>
      <div className="choice-row">
        {choices.map((c) => (
          <button key={c.word} className="choice-item" onClick={() => choose(c)}>
            <div className="choice-orb" style={{ fontSize: 16, fontWeight: 800 }}>{c.word}</div>
          </button>
        ))}
      </div>
    </div>
  );
}
WordRecognitionRound.subtitle = 'Match the picture to the written word.';
